#!/bin/sh

# Disabled. Use autodownload
# git clone --depth 1 https://github.com/FWGS/vgui-dev
# git clone --depth 1 https://github.com/FWGS/vgui_support_bin 
