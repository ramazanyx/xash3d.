#define EXTERN_PREFIX ""
#define ARCH_X86_32 1
